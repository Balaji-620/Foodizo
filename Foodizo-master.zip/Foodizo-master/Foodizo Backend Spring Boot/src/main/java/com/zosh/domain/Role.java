package com.zosh.domain;

public enum Role {
	
	    ROLE_CUSTOMER,
	    ROLE_RESTAURANT_OWNER,
	    ROLE_ADMIN

}
