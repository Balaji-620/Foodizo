package com.zosh.Exception;

public class MenuItemException extends Exception {

	public MenuItemException(String message) {
		super(message);

	}

}
